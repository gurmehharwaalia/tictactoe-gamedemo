import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Settings } from 'lucide-react';

interface GameSettings {
  playerXName: string;
  playerOName: string;
  gameMode: 'pvp' | 'ai';
  aiDifficulty: 'easy' | 'medium' | 'hard';
}

interface Scores {
  x: number;
  o: number;
  draws: number;
}

function Square({ value, onSquareClick, index }: { value: string | null; onSquareClick: () => void; index: number }) {
  return (
    <button
      className="w-24 h-24 md:w-32 md:h-32 flex items-center justify-center text-5xl md:text-6xl font-bold text-foreground hover-elevate active-elevate-2 transition-all duration-150 bg-card border-card-border"
      onClick={onSquareClick}
      data-testid={`button-square-${index}`}
    >
      {value}
    </button>
  );
}

function Board({ 
  xIsNext, 
  squares, 
  onPlay, 
  settings 
}: { 
  xIsNext: boolean; 
  squares: (string | null)[]; 
  onPlay: (nextSquares: (string | null)[]) => void;
  settings: GameSettings;
}) {
  function handleClick(i: number) {
    if (squares[i] || calculateWinner(squares)) return;
    const nextSquares = squares.slice();
    nextSquares[i] = xIsNext ? 'X' : 'O';
    onPlay(nextSquares);
  }

  const winner = calculateWinner(squares);
  let status;
  if (winner) {
    const winnerName = winner === 'X' ? settings.playerXName : settings.playerOName;
    status = `Winner: ${winnerName}!`;
  } else if (!squares.includes(null)) {
    status = "It's a Draw!";
  } else {
    const currentPlayer = xIsNext ? settings.playerXName : settings.playerOName;
    status = `${currentPlayer}'s Turn`;
  }

  return (
    <div className="flex flex-col items-center gap-8">
      <h1 className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-title">
        Tic-Tac-Toe
      </h1>
      
      <div className="inline-grid grid-cols-3 bg-card rounded-lg overflow-hidden shadow-lg border-2 border-card-border">
        {/* Row 1 */}
        <div className="border-r-2 border-b-2 border-card-border">
          <Square value={squares[0]} onSquareClick={() => handleClick(0)} index={0} />
        </div>
        <div className="border-r-2 border-b-2 border-card-border">
          <Square value={squares[1]} onSquareClick={() => handleClick(1)} index={1} />
        </div>
        <div className="border-b-2 border-card-border">
          <Square value={squares[2]} onSquareClick={() => handleClick(2)} index={2} />
        </div>
        
        {/* Row 2 */}
        <div className="border-r-2 border-b-2 border-card-border">
          <Square value={squares[3]} onSquareClick={() => handleClick(3)} index={3} />
        </div>
        <div className="border-r-2 border-b-2 border-card-border">
          <Square value={squares[4]} onSquareClick={() => handleClick(4)} index={4} />
        </div>
        <div className="border-b-2 border-card-border">
          <Square value={squares[5]} onSquareClick={() => handleClick(5)} index={5} />
        </div>
        
        {/* Row 3 */}
        <div className="border-r-2 border-card-border">
          <Square value={squares[6]} onSquareClick={() => handleClick(6)} index={6} />
        </div>
        <div className="border-r-2 border-card-border">
          <Square value={squares[7]} onSquareClick={() => handleClick(7)} index={7} />
        </div>
        <div>
          <Square value={squares[8]} onSquareClick={() => handleClick(8)} index={8} />
        </div>
      </div>

      <div className="text-xl md:text-2xl font-semibold text-foreground mb-4" data-testid="text-game-status">
        {status}
      </div>
    </div>
  );
}

export default function Home() {
  const [history, setHistory] = useState<(string | null)[][]>([Array(9).fill(null)]);
  const [currentMove, setCurrentMove] = useState(0);
  const [showSetup, setShowSetup] = useState(true);
  const [scores, setScores] = useState<Scores>({ x: 0, o: 0, draws: 0 });
  const [settings, setSettings] = useState<GameSettings>({
    playerXName: 'Player X',
    playerOName: 'Player O',
    gameMode: 'pvp',
    aiDifficulty: 'medium'
  });
  const [tempSettings, setTempSettings] = useState<GameSettings>(settings);

  const xIsNext = currentMove % 2 === 0;
  const currentSquares = history[currentMove];

  // Load saved settings and scores from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('tictactoe-settings');
    const savedScores = localStorage.getItem('tictactoe-scores');
    
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      setSettings(parsed);
      setTempSettings(parsed);
      setShowSetup(false);
    }
    
    if (savedScores) {
      setScores(JSON.parse(savedScores));
    }
  }, []);

  // Save scores to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('tictactoe-scores', JSON.stringify(scores));
  }, [scores]);

  function handlePlay(nextSquares: (string | null)[]) {
    const nextHistory = [...history.slice(0, currentMove + 1), nextSquares];
    setHistory(nextHistory);
    setCurrentMove(nextHistory.length - 1);

    // Check if game ended and update scores
    const winner = calculateWinner(nextSquares);
    if (winner) {
      setScores(prev => ({
        ...prev,
        [winner.toLowerCase()]: prev[winner.toLowerCase() as 'x' | 'o'] + 1
      }));
    } else if (!nextSquares.includes(null)) {
      setScores(prev => ({ ...prev, draws: prev.draws + 1 }));
    }
  }

  function handleRestart() {
    setHistory([Array(9).fill(null)]);
    setCurrentMove(0);
  }

  function handleStartGame() {
    setSettings(tempSettings);
    localStorage.setItem('tictactoe-settings', JSON.stringify(tempSettings));
    setShowSetup(false);
  }

  function handleResetScores() {
    setScores({ x: 0, o: 0, draws: 0 });
    localStorage.removeItem('tictactoe-scores');
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-8 bg-background">
      <div className="flex flex-col items-center gap-6 w-full max-w-4xl">
        {/* Scoreboard */}
        {!showSetup && (
          <Card className="w-full max-w-md p-6 mb-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-foreground" data-testid="text-scoreboard-title">Scoreboard</h2>
              <Button 
                size="icon" 
                variant="ghost"
                onClick={() => setShowSetup(true)}
                data-testid="button-settings"
              >
                <Settings className="w-5 h-5" />
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-foreground" data-testid="text-score-x">{scores.x}</div>
                <div className="text-sm text-muted-foreground" data-testid="text-player-x">{settings.playerXName}</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground" data-testid="text-score-draws">{scores.draws}</div>
                <div className="text-sm text-muted-foreground">Draws</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground" data-testid="text-score-o">{scores.o}</div>
                <div className="text-sm text-muted-foreground" data-testid="text-player-o">{settings.playerOName}</div>
              </div>
            </div>
          </Card>
        )}

        {/* Game Board */}
        {!showSetup && (
          <>
            <Board xIsNext={xIsNext} squares={currentSquares} onPlay={handlePlay} settings={settings} />
            <div className="flex gap-4">
              <Button
                onClick={handleRestart}
                className="px-8 py-3 text-lg font-semibold"
                variant="secondary"
                data-testid="button-restart"
              >
                New Game
              </Button>
              <Button
                onClick={handleResetScores}
                variant="outline"
                data-testid="button-reset-scores"
              >
                Reset Scores
              </Button>
            </div>
          </>
        )}

        {/* Setup Dialog */}
        <Dialog open={showSetup} onOpenChange={setShowSetup}>
          <DialogContent className="max-w-md" data-testid="dialog-setup">
            <DialogHeader>
              <DialogTitle>Game Setup</DialogTitle>
              <DialogDescription>
                Customize your game settings and player names
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6 py-4">
              {/* Game Mode Selection */}
              <div>
                <label className="text-sm font-semibold text-foreground mb-3 block">
                  Game Mode
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant={tempSettings.gameMode === 'pvp' ? 'default' : 'outline'}
                    onClick={() => setTempSettings({ ...tempSettings, gameMode: 'pvp' })}
                    data-testid="button-mode-pvp"
                    className="w-full"
                  >
                    2 Players
                  </Button>
                  <Button
                    variant={tempSettings.gameMode === 'ai' ? 'default' : 'outline'}
                    onClick={() => setTempSettings({ ...tempSettings, gameMode: 'ai' })}
                    data-testid="button-mode-ai"
                    className="w-full"
                  >
                    vs AI
                  </Button>
                </div>
              </div>

              {/* AI Difficulty (only show if AI mode selected) */}
              {tempSettings.gameMode === 'ai' && (
                <div>
                  <label className="text-sm font-semibold text-foreground mb-3 block">
                    AI Difficulty
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={tempSettings.aiDifficulty === 'easy' ? 'default' : 'outline'}
                      onClick={() => setTempSettings({ ...tempSettings, aiDifficulty: 'easy' })}
                      data-testid="button-difficulty-easy"
                      size="sm"
                    >
                      Easy
                    </Button>
                    <Button
                      variant={tempSettings.aiDifficulty === 'medium' ? 'default' : 'outline'}
                      onClick={() => setTempSettings({ ...tempSettings, aiDifficulty: 'medium' })}
                      data-testid="button-difficulty-medium"
                      size="sm"
                    >
                      Medium
                    </Button>
                    <Button
                      variant={tempSettings.aiDifficulty === 'hard' ? 'default' : 'outline'}
                      onClick={() => setTempSettings({ ...tempSettings, aiDifficulty: 'hard' })}
                      data-testid="button-difficulty-hard"
                      size="sm"
                    >
                      Hard
                    </Button>
                  </div>
                </div>
              )}

              {/* Player Names */}
              <div>
                <label htmlFor="playerX" className="text-sm font-semibold text-foreground mb-2 block">
                  Player X Name
                </label>
                <Input
                  id="playerX"
                  value={tempSettings.playerXName}
                  onChange={(e) => setTempSettings({ ...tempSettings, playerXName: e.target.value })}
                  placeholder="Enter name for X"
                  data-testid="input-player-x"
                />
              </div>

              <div>
                <label htmlFor="playerO" className="text-sm font-semibold text-foreground mb-2 block">
                  {tempSettings.gameMode === 'ai' ? 'AI Name' : 'Player O Name'}
                </label>
                <Input
                  id="playerO"
                  value={tempSettings.playerOName}
                  onChange={(e) => setTempSettings({ ...tempSettings, playerOName: e.target.value })}
                  placeholder="Enter name for O"
                  data-testid="input-player-o"
                />
              </div>
            </div>

            <Button 
              onClick={handleStartGame} 
              className="w-full"
              data-testid="button-start-game"
            >
              Start Game
            </Button>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

function calculateWinner(squares: (string | null)[]) {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}
