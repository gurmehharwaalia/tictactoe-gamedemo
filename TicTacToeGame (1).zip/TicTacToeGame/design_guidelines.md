# Tic-Tac-Toe Game Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern casual game interfaces with clean, minimalist aesthetics. The design follows the provided screenshot showing a mint/teal background with a beige game board, emphasizing clarity and playful simplicity.

## Core Design Principles
- **Playful Minimalism**: Clean interface focusing on gameplay without distractions
- **Clear Visual Hierarchy**: Game board as primary focus, supporting elements secondary
- **Instant Feedback**: Visual states that communicate game status immediately
- **Accessible Interaction**: Large touch targets and clear affordances

## Layout System

**Container Structure**:
- Centered layout with vertical stacking
- Game board as focal point in viewport center
- Use Tailwind spacing units: **2, 4, 8, 12, 16** for consistent rhythm
- Container padding: `p-8` on mobile, `p-12` on desktop

**Vertical Spacing**:
- Status text to board: `mb-8`
- Board to restart button: `mt-12`
- Board squares: `gap-0` (borders create visual separation)

**Board Dimensions**:
- Fixed square size: `w-24 h-24` (96px) for each cell on mobile
- Desktop: `w-32 h-32` (128px) for comfortable clicking
- Total board: approximately 288px on mobile, 384px on desktop

## Typography

**Primary Font**: System font stack for optimal performance
```
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif
```

**Type Scale**:
- **Game Status/Title**: `text-3xl` (30px), `font-bold`, centered, `mb-8`
- **X and O Markers**: `text-5xl` (48px) on mobile, `text-6xl` (60px) on desktop, `font-bold`
- **Restart Button**: `text-lg` (18px), `font-semibold`
- **Move History** (if shown): `text-base` (16px), `font-normal`

**Line Height**: Use default Tailwind line heights for all text elements

## Component Specifications

### Game Board
- **Container**: `grid grid-cols-3` with no gap between cells
- **Border Treatment**: 
  - Inner cells have borders on right and bottom
  - Edge cells omit outer borders for clean edge
  - Border width: `border-2` or `border-3` for clear definition
- **Rounded Corners**: `rounded-lg` on outer container
- **Shadow**: `shadow-lg` for depth and elevation

### Square Cells
- **Dimensions**: Square aspect ratio maintained with explicit width/height
- **Hover State**: Subtle background lightening on empty squares
- **Active State**: Slight scale down (`scale-95`) on click
- **Cursor**: `cursor-pointer` on empty squares, `cursor-default` on filled
- **Transition**: `transition-all duration-150` for smooth interactions

### X and O Markers
- **X Marker**: Bold, sans-serif character
- **O Marker**: Bold, sans-serif character
- **Vertical Alignment**: Centered using flexbox (`flex items-center justify-center`)
- **No additional styling**: Let typography weight carry visual presence

### Restart Button
- **Size**: `px-8 py-3` for comfortable touch target
- **Border Radius**: `rounded-lg` matching board
- **Typography**: `font-semibold` for emphasis
- **Shadow**: `shadow-md` at rest
- **Hover Effect**: Slight lift with `shadow-lg` and `translate-y-[-2px]`
- **Active State**: Press down with `scale-95`
- **Transition**: `transition-all duration-200`

### Status Display
- **Position**: Above board, centered
- **Spacing**: `mb-8` from board
- **Text Treatment**: Bold, large text for readability
- **Dynamic Content**: 
  - "Next player: X" or "Next player: O"
  - "Winner: X" or "Winner: O"
  - "Draw!" when board is full

### Move History (Optional Display)
- **Position**: Below restart button or in side panel
- **List Style**: Numbered list with buttons for each move
- **Button Style**: Text buttons with subtle hover underline
- **Spacing**: `space-y-2` between moves

## Visual Treatment

**Background**: 
- Main container: Mint/teal solid color as shown in reference
- Game board: Beige/tan solid color creating contrast

**Board Border Colors**:
- Dark charcoal or deep gray for clear grid definition
- Maintain consistent border width throughout

**Text Colors**:
- Primary text (status): Dark gray or charcoal for readability
- X and O markers: Same dark color for consistency
- Button text: Dark color on light button background

**Button Background**:
- Restart button: Beige matching board or complementary neutral

## Responsive Behavior

**Mobile (< 768px)**:
- Squares: `w-24 h-24`
- Status text: `text-2xl`
- Restart button: Full width with `w-full max-w-xs`
- Padding: `p-8`

**Desktop (≥ 768px)**:
- Squares: `w-32 h-32`
- Status text: `text-3xl`
- Restart button: Auto width with adequate padding
- Padding: `p-12`

## Interaction States

**Empty Square Hover**:
- Subtle background lightening (5-10% lighter)
- Maintain cursor pointer
- Smooth transition

**Filled Square**:
- No hover effect
- Cursor default
- Locked visual state

**Button States**:
- **Rest**: Base styling with shadow
- **Hover**: Lift effect with enhanced shadow
- **Active**: Press down effect
- **Focus**: Outline ring for keyboard navigation

## Accessibility Considerations

- **Focus Indicators**: Visible `ring-2 ring-offset-2` on keyboard focus
- **Touch Targets**: Minimum 96px (w-24 h-24) for comfortable tapping
- **Contrast Ratios**: Ensure 4.5:1 minimum for all text
- **Screen Reader**: Announce winner and turn changes
- **Keyboard Navigation**: Tab through squares and restart button

## Animation Guidelines

**Use Sparingly**:
- Square click: Brief scale animation (`duration-150`)
- Button interactions: Lift/press effects (`duration-200`)
- Winner announcement: Fade-in effect if desired
- **Avoid**: Elaborate entrance animations, spinning elements, or distracting effects

**Performance**:
- Use CSS transforms (translate, scale) only
- Avoid animating width, height, or margin
- Keep durations under 300ms for snappy feel

## Game Flow UX

1. **Initial State**: Clean board, "Next player: X" status
2. **During Play**: Immediate marker placement, turn indicator updates
3. **Win State**: Winner announcement, highlight winning line (optional)
4. **Draw State**: Clear "Draw!" message
5. **Restart**: Instant reset to initial state, smooth transition

This design creates a polished, playable Tic-Tac-Toe experience that prioritizes clarity, usability, and the specific aesthetic shown in the reference screenshot.